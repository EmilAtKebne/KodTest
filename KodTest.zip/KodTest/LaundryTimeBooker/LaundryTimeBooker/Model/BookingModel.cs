﻿namespace LaundryTimeBooker.Model
{
    public class BookingModel
    {
        public string? PersonalIdenificationNumber { get; set; }
        public Room Room { get; set; }
        public string? HouseHoldId { get; set; }
        public bool ShowWarning { get; set; }
        public List<LaundryDay>? Days { get; set; }
        public string SelectedSlot { get; set; }
    }

    public enum Room
    {
        A,
        B
    }

}
