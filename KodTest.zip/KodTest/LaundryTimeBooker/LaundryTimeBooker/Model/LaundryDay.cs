﻿namespace LaundryTimeBooker.Model
{
    public class LaundryDay
    {
        public DateTime Date { get; set; }
        public List<TimeSlot> TimeSlots { get; set; }
    }

    public class TimeSlot
    {
        public string Id { get; set; }
        public int StartHour { get; set; }
        public int EndHour { get; set; }
        public bool IsBooked { get; set; }
        public string BookedByHouseHoldId { get; set; }
    }
}
