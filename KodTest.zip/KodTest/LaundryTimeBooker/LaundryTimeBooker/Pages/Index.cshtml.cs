﻿using LaundryTimeBooker.Application;
using LaundryTimeBooker.Mappers;
using LaundryTimeBooker.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LaundryTimeBooker.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILoginService _loginService;
        private readonly ILaundrySlotService _laundrySlotService;

        public IndexModel(ILoginService loginService, ILaundrySlotService laundrySlotService)
        {
            _loginService = loginService;
            _laundrySlotService = laundrySlotService;
        }

        [BindProperty]
        public BookingModel BookingModel { get; set; }

        public async Task OnPostBook()
        {
            var room = (Application.Models.Room)BookingModel.Room;
            await _laundrySlotService.BookTimeAsync(BookingModel.HouseHoldId, BookingModel.SelectedSlot, room);

            BookingModel.Days = LaundryDayMapper.Map(await _laundrySlotService.GetLaundryTimesAsync(room));
        }
        public async Task OnPostUnbook()
        {
            var room = (Application.Models.Room)BookingModel.Room;
            await _laundrySlotService.UnbookTimeAsync(BookingModel.SelectedSlot);

            BookingModel.Days = LaundryDayMapper.Map(await _laundrySlotService.GetLaundryTimesAsync(room));
        }

        public async Task OnPostLogin()
        {
            try
            {
                BookingModel.HouseHoldId = await _loginService.LoginAsync(BookingModel?.PersonalIdenificationNumber);

                var room = (Application.Models.Room) BookingModel.Room;
                BookingModel.Days = LaundryDayMapper.Map(await _laundrySlotService.GetLaundryTimesAsync(room));
            }
            catch(Exception ex)
            {
                BookingModel.ShowWarning = true;
            }
        }
    }
}