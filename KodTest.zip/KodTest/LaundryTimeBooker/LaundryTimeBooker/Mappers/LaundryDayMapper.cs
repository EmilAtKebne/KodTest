﻿using LaundryTimeBooker.Model;

namespace LaundryTimeBooker.Mappers
{
    public static class LaundryDayMapper
    {
        public static List<LaundryDay> Map(List<Application.Models.LaundryDay> laundryDays)
            => laundryDays.Select(Map).ToList();

        public static LaundryDay Map(Application.Models.LaundryDay laundryDay)
            => new LaundryDay
            {
                Date = laundryDay.Date,
                TimeSlots = laundryDay.TimeSlot.Select(Map).ToList()
            };

        private static TimeSlot Map(Application.Models.TimeSlot timeSlot)
            => new TimeSlot
            {
                Id = timeSlot.Id,
                BookedByHouseHoldId = timeSlot.BookedByHouseHoldId,
                IsBooked = timeSlot.IsBooked,
                StartHour = timeSlot.StartHour,
                EndHour = timeSlot.EndHour
            };
    }
}
