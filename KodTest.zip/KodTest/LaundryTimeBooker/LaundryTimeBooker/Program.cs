using LaundryTimeBooker.Application;
using LaundryTimeBooker.DataAccess;

var builder = WebApplication.CreateBuilder(args);

var connection =
    System.Configuration.ConfigurationManager.
    ConnectionStrings["Default"].ConnectionString;

var sqlLiteService = new SqlLiteService(connection);


builder.Services.AddRazorPages();
builder.Services.AddTransient<ILoginService, LoginService>();
builder.Services.AddTransient<ILaundrySlotService, LaundrySlotService>();
builder.Services.AddSingleton<ISqlLiteService>(sqlLiteService);

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.MapRazorPages();

app.Run();
