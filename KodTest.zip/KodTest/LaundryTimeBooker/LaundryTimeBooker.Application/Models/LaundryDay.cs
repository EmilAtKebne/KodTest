﻿namespace LaundryTimeBooker.Application.Models
{

    public class LaundryDay
    {
        public DateTime Date { get; set; }
        public List<TimeSlot> TimeSlot { get; set; }
    }

    public class TimeSlot
    {
        public string Id { get; set; }
        public int StartHour { get; set; }
        public int EndHour { get; set; }
        public bool IsBooked { get; set; }
        public string BookedByHouseHoldId { get; set; }
    }
}

