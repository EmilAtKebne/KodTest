﻿namespace LaundryTimeBooker.Application.Models
{
    public enum Room
    {
        A,
        B
    }
}
