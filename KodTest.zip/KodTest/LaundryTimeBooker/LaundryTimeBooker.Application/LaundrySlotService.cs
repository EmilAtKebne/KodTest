﻿using LaundryTimeBooker.Application.Models;
using LaundryTimeBooker.DataAccess;
using LaundryTimeBooker.DataAccess.Models;

namespace LaundryTimeBooker.Application
{
    public interface ILaundrySlotService
    {
        Task<List<LaundryDay>> GetLaundryTimesAsync(Room room);
        Task BookTimeAsync(string houseHoldId, string id, Room room);
        Task UnbookTimeAsync(string id);
    }
    public class LaundrySlotService : ILaundrySlotService
    {
        private readonly ISqlLiteService _sqlService;
        public LaundrySlotService(ISqlLiteService sqlService)
            => _sqlService = sqlService;
        public async Task<List<LaundryDay>> GetLaundryTimesAsync(Room room)
        {
            var laundryDays = GenerateLaundryDays();
            await CheckBookingsAsync(laundryDays, room);
            return laundryDays;
        }

        private List<LaundryDay> GenerateLaundryDays()
        {
            var laundryDays = new List<LaundryDay>();

            for (DateTime date = DateTime.Today; date < DateTime.Today.AddDays(14); date = date.AddDays(1))
            {
                var laundryDay = new LaundryDay
                {
                    Date = date,
                    TimeSlot = new List<TimeSlot>
                    {
                        new TimeSlot { Id= date+"S0", StartHour = 7, EndHour = 10 },
                        new TimeSlot { Id= date+"S1", StartHour = 10, EndHour = 13 },
                        new TimeSlot { Id= date+"S2", StartHour = 13, EndHour = 16 },
                        new TimeSlot { Id= date+"S3", StartHour = 16, EndHour = 19 },
                        new TimeSlot { Id= date+"S4", StartHour = 19, EndHour = 22 }
                    }
                };

                laundryDays.Add(laundryDay);
            }

            return laundryDays;
        }

        private async Task<List<LaundryDay>> CheckBookingsAsync(List<LaundryDay> laundryDays, Room room)
        {
            var bookings = await _sqlService.GetBookingsByDateAsync(DateTime.Today.Date, room.ToString());
            foreach (var booking in bookings)
            {
                var day = laundryDays.Where(ld => ld.Date.Date == booking.Date.Date).FirstOrDefault();
                if (day is not null)
                {
                    var slot = day.TimeSlot[booking.Slot];
                    slot.Id = booking.Id.ToString();
                    slot.BookedByHouseHoldId = booking.BookedBy;
                    slot.IsBooked = true;
                }
            }
            return laundryDays;
        }

        public async Task BookTimeAsync(string houseHoldId, string id, Room room)
        {
            var bookingData = id.Split('S');

            DateTime date = DateTime.ParseExact(bookingData[0], "yyyy-MM-dd HH:mm:ss",
                                       System.Globalization.CultureInfo.InvariantCulture);
            var booking = new Booking
            {
                BookedBy = houseHoldId,
                Room = room.ToString(),
                Slot = int.Parse(bookingData[1]),
                Date = date,
            };

            await _sqlService.BookAsync(booking);
        }

        public async Task UnbookTimeAsync(string id)
            =>  await _sqlService.UnbookAsync(id);
    }
}