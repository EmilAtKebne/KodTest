﻿using LaundryTimeBooker.DataAccess;

namespace LaundryTimeBooker.Application
{

    public interface ILoginService
    {
        Task<string> LoginAsync(string personalidentificationnumber);
    }

    public class LoginService : ILoginService
    {
        private readonly ISqlLiteService _sqlService;
        public LoginService(ISqlLiteService sqlService)
            => _sqlService = sqlService;

        public async Task<string> LoginAsync(string personalidentificationnumber)
        {
            if (string.IsNullOrWhiteSpace(personalidentificationnumber) || personalidentificationnumber.Length != 12)
                throw new ArgumentException("personalidentificationnumber invalid"); //Should not be 500
            else
            {

                var houseHoldId = await _sqlService.GetHouseHoldIdAsync(personalidentificationnumber);
                if (houseHoldId == null)
                    throw new Exception("Not found");  //Should not be 500
                else
                    return houseHoldId;
            }
        }
    }
}