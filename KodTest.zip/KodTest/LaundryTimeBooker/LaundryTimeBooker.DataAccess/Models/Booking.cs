﻿using System.Data.SqlTypes;

namespace LaundryTimeBooker.DataAccess.Models
{
    public class Booking
    {
        public int Id { get; set; }
        public string BookedBy { get; set; }
        public int Slot { get; set; }
        public DateTime Date { get; set; }
        public string Room { get; set; }
    }
}
