﻿using Dapper;
using LaundryTimeBooker.DataAccess.Models;
using System.Data;
using System.Data.SQLite;

namespace LaundryTimeBooker.DataAccess
{
    public interface ISqlLiteService
    {
        Task<string> GetHouseHoldIdAsync(string personalidentificationnumber);
        Task<IEnumerable<Booking>> GetBookingsByDateAsync(DateTime date, string room);
        Task BookAsync(Booking booking);
        Task UnbookAsync(string id);
    }

    public class SqlLiteService : ISqlLiteService
    {
        private string ConnectionString = string.Empty;
        //private readonly string ConnectionString = "Data Source = C:/Users/emil9/source/repos/LaundryTimeBooker/LaundryTimeBooker.DataAccess/LaundryTimeBookerDB.db;Version=3;";

        public SqlLiteService(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public async Task<string> GetHouseHoldIdAsync(string personalidentificationnumber)
        {
            using IDbConnection cnn = new SQLiteConnection(ConnectionString);

            var query = $"SELECT HouseHoldId FROM Person WHERE Pin='{personalidentificationnumber}'";
            var houseHoldId = await cnn.QueryFirstAsync<string>(query);

            return houseHoldId;
        }

        public async Task<IEnumerable<Booking>> GetBookingsByDateAsync(DateTime date, string room)
        {
            using IDbConnection cnn = new SQLiteConnection(ConnectionString);
            var query = $"SELECT * FROM Bookings WHERE Room = '{room}'";
            var result = await cnn.QueryAsync(query);

            var bookings = new List<Booking>();

            foreach (var booking in result)
            {
                bookings.Add(new Booking {
                    Id = (int) booking.Id,
                    BookedBy = booking.BookedBy,
                    Slot = (int) booking.Slot,
                    Date = DateTime.ParseExact(booking.Date, "yyyy-MM-dd HH:mm:ss", null),
                    Room = booking.Room,
                });
            }
           
            return bookings;
        }

        public async Task BookAsync(Booking booking)
        {
            using IDbConnection cnn = new SQLiteConnection(ConnectionString);
            var query = $"INSERT INTO Bookings (BookedBy,Date,Slot,Room) VALUES (@BookedBy, @Date, @Slot, @Room)";
            var result = await cnn.ExecuteAsync(query, booking);
        }

        public async Task UnbookAsync(string id)
        {
            using IDbConnection cnn = new SQLiteConnection(ConnectionString);
            var query = $"DELETE FROM Bookings WHERE Id ={id}";
            var result = await cnn.ExecuteAsync(query);
        }

    }
}