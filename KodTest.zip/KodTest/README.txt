Några testpersoner
195903301728
195903301729
195903301731

Notera 195903301729, 195903301731 bor tillsammans

Välj mellan Rum A och B

För att nå databasen behöver du byta ut connectionStringen(den ska peka på databasen i dataAccess aka LaundryTimeBooker.DataAccess)
Du byter ut värdet i App.Config huvudprojetet